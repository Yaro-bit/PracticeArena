package com.upperaustria.simplesales.exception;

public class ResourceNotFoundException {

}
//Eine benutzerdefinierte Exception für den Fall, dass eine Ressource (z.B. eine Adresse)nicht gefunden wird.