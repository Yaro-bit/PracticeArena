package com.upperaustria.simplesales.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

public class AddressController {
	
//	@GetMapping 		//für das Abrufen aller Adressen
//	
//	@PostMapping 		//für das Erstellen einer neuen Adresse
//	
//	@PutMapping 		//für das Aktualisieren einer Adresse (optional)
//	
//	@DeleteMapping 		//für das Löschen einer Adresse (optional)
	
}
