package com.upperaustria.simplesales;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleSalesApplication {
    public static void main(String[] args) {
        SpringApplication.run(SimpleSalesApplication.class, args);
    }
}
