package com.upperaustria.simplesales.repository;

public class NoteRepository {

}
