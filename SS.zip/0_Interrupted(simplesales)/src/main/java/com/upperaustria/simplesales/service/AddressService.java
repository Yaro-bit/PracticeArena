package com.upperaustria.simplesales.service;

import com.upperaustria.simplesales.model.Address;

public class AddressService {
	void getAllAddresses() {

	}

	void addAddress(Address address) {

	}

	void updateAddress(Address address) {

	}

	void deleteAddress(Long id) {

	}
}
//Diese Klasse enthält die Business-Logik für das Arbeiten mit Adressen. 
//Sie kommuniziert mit dem AddressRepository und führt die eigentlichen Operationen durch.