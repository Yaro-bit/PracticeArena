package com.upperaustria.simplesales.model;

public enum AddressStatus {
    OFFEN,
    IN_BETRIEB,
    ERLEDIGT
    
}
