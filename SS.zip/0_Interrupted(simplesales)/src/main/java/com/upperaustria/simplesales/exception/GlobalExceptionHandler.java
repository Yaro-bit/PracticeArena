package com.upperaustria.simplesales.exception;

public class GlobalExceptionHandler {

}
//Eine globale Fehlerbehandlungs-Bean, die mit @ControllerAdvice arbeitet und 
//Fehlerbehandlungen für die gesamte Anwendung zentralisiert.