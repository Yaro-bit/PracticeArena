package com.upperaustria.simplesales.service;

public class NoteService {

}
//Diese Klasse führt die Business-Logik für Notizen aus, z.B. das Erstellen und Abrufen von Notizen.