package com.upperaustria.simplesales.controller;

public class NoteController {

}
