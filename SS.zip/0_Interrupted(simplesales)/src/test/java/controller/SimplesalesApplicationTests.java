package controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimplesalesApplicationTests {

	@Test
	void contextLoads() {
	}

}
//http://localhost:8080/upload.html
//	http://localhost:8080/adresse
//			http://localhost:8080/