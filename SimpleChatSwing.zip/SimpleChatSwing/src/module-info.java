/**
 * 
 */
/**
 * 
 */
module SimpleChat {
    exports chatServer; // Export package to all modules
    requires java.rmi;
	requires java.desktop;  // Declare dependency on RMI
}
