package com.practice.yaro.photoclone.photoclone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhotocloneApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhotocloneApplication.class, args);
	}

}
