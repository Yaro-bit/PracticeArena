package com.practice.yaro.photoclone.photoclone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotocloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
