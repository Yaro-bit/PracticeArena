package basics;
public class TenLoop {

	public static void main(String[] args) {
		for(int i = 10; i<=40;i=i+10) {
			System.out.println(i);
		}
	}

}

//5: Schreibe ein Programm, das die Zahlen von 10 bis 40 in 10er-Schritten ausgibt.