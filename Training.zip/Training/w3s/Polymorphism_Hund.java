package w3s;

public class Polymorphism_Hund {
	public void animalSound() {
		System.out.println("Der Hund ist deppad");
	}
}
