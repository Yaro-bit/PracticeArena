package w3s;

public class InnerClass_Outer {
	int x = 10;

	static class InnerClass_Inner {
		int y = 5;
	}

	class InnerClass_Inner_c {
		int y = 6;
	}

	private class InnerClass_Inner_p {
		int y = 5;
	}
}