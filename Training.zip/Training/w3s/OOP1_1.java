package w3s;

class OOP1_1 {
	public static void main(String[] args) {
		OOP1 meinMainAlsObject = new OOP1();
		System.out.println(meinMainAlsObject.x);
	}
}