package w3s;

public class OOP1 {
	int x =5;
	
//	public static void main (String[] args) {
//		Main meinMainAlsObject = new Main();
//		Main meinMainAlsObject2 = new Main();
//
//		System.out.println(meinMainAlsObject.x);
//		System.out.println(meinMainAlsObject2.x);
//	}

}

