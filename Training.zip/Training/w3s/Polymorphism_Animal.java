package w3s;

public class Polymorphism_Animal {

	public void AnimalSound() {
		System.out.println("The animal makes a sound");
	}
	
	
}
