package w3s;

public class Polymorphism_Pig extends Polymorphism_Animal {
	public void animalSound() {
		System.out.println("Schwein macht: \"S**g *eil\"");
	}
}
