
package w3s;

import java.util.Scanner;

public class PackageScanner {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Wirte \"fuck\":");
		String word = scan.nextLine();
		System.out.println("Your word is: "+word);
	}

}

