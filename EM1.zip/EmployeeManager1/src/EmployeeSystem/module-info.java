
module Arbeitersystem {
}