/**
 * 
 */
/**
 * @author yaros
 *
 */
module ChatClient {
}